باقی مونده برای تکمیل نسخه‌ی آفلاین:

پوشه‌ی geojson همینجا خالیه. باید این ۸ فایل رو داخلش بذارید (دقیقاً با همین اسم‌ها):

gadm41_GBR_1.json  <- https://super-duper.fr/geojson/prov/gadm41_GBR_1.json
gadm41_FRA_1.json  <- https://super-duper.fr/geojson/prov/gadm41_FRA_1.json
gadm41_DEU_1.json  <- https://super-duper.fr/geojson/prov/gadm41_DEU_1.json
gadm41_BEL_1.json  <- https://super-duper.fr/geojson/prov/gadm41_BEL_1.json
gadm41_NLD_1.json  <- https://super-duper.fr/geojson/prov/gadm41_NLD_1.json
gadm41_LUX_1.json  <- https://super-duper.fr/geojson/prov/gadm41_LUX_1.json
gadm41_CHE_1.json  <- https://super-duper.fr/geojson/prov/gadm41_CHE_1.json
gadm41_ITA_1.json  <- https://super-duper.fr/geojson/prov/gadm41_ITA_1.json

روش: هر لینک رو تو مرورگر باز کن، Select All -> Copy، بعد با اپ Text Editor
یه فایل جدید با همون اسم بساز و Paste/Save کن.

بعد از اینکه این ۸ فایل رو گذاشتی، این پوشه (با همه‌ی فایل‌هاش) رو یکجا
فشرده (zip) کن و آماده‌ی پکیج‌کردن با Capacitor به APK می‌شه.
